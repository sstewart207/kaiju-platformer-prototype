# Kaiju Unity prototype

Open this folder in **Unity 6000.6.3f1**, open `Assets/Scenes/Ruins.unity` and press Play. The scene uses the Built-in Render Pipeline and the Unity Input System. This is the four-legged Solargon design study. It keeps the four wings, crown horns, chest sun and star-tipped tail from Patrick's concept.

| Action | Keyboard and mouse | DualSense |
| --- | --- | --- |
| Move | WASD or arrows | Left stick or D-pad |
| Orbit | Q / E or right mouse drag | Right stick |
| Center camera | C | Click right stick |
| Jump | Space, hold for height | Cross, hold for height |
| Dash | Left Shift | Square or R1 |
| Pause | Esc | Options |
| Restart | R | Triangle |

Follow the sandstone path to the gate or try the jump terraces to the left. This prototype covers the model, camera and traversal. Combat, the full browser Ruins course, collectibles and the other characters are outside this first pass.

Movement follows a third-person perspective camera. The camera settles behind Solargon after you release a turn, angles down to show the ground ahead, and moves closer when scenery gets in the way. A short jump buffer and grace period at ledges help with timing. Tap Jump for a hop or hold it for height.

Solargon carves a short arc through a running turn. He slows to change direction on tight corners, leans into the turn, and leads the tail around behind him. The keyboard and stick camera orbit eases in and out.

## Next playtest

- Prototype a boost turn. While the player holds boost and steers into a sharp ground turn, let Solargon slide briefly, emit a short smoke trail from the paws that are sliding, and restore grip as he exits the turn. Playtest the balance between the skid and steering control.

## Ruins Encounter

Open `Assets/Scenes/RuinsEncounter.unity` and press Play in the docked Game tab. Walk up the sandstone steps to the gallery. Dash through the zombie with Shift or Square to unlock the sun gate, then walk through. If the zombie's windup connects, Solargon returns to the start. R or Triangle restarts the encounter.

This is the first playable section of the browser Ruins port. Test the stairs, camera around the gallery walls, and the single encounter before adding the remaining rooms, checkpoints, or combat moves. `Kaiju → Build Ruins Encounter` regenerates the scene from the original Unity traversal test.

## Solargon animation

`Assets/Models/SolargonRig/Solargon Visual.prefab` contains four hip–knee–ankle chains. Each lower-leg mesh bends across the knee. The feet land in sequence, hind then front on each side, and each foot spends most of the stride supporting weight. The low swing and flatter upper body take cues from crocodilian high walking. The rig tucks the legs on takeoff and dips on landing. Dirt particles emit at ground contact. [Crocodilian gait research](https://academic.oup.com/icb/article/62/5/1281/6590043)

`Assets/Scripts/KaijuGait.cs` contains the shared motion. For a new character, set up its joints, fit the foot clearance, and set each leg's phase for that body shape. The earlier six-legged build is available separately for comparison.

Use Patrick's concept sheet to fit each character's silhouette. Keep the proportions compact and give the body and feet enough mass to read as a small kaiju. Solargon uses a blunt dragon muzzle, a broad chest, and a lower, deliberate run. Keep each selected character's own face, anatomy, and stride.

## Unity MCP

The project pins [MCP for Unity](https://github.com/CoplayDev/unity-mcp) v10.3.0. With the project open, go to **Window → MCP for Unity**, use local HTTP, start the server and connect the editor. The [upstream setup guide](https://coplaydev.github.io/unity-mcp/getting-started/install) covers Python and uv if Unity prompts for them.

## Model provenance

The Solargon sheet in the supplied `patricks kaiju download (2).docx` was used as visual reference. The model geometry was built in Blender. The FBX is embedded in this project. The editable Blender source and the GLB are delivered separately. `Kaiju → Rebuild Ruins Prototype` regenerates the sample scene and its materials from the FBX.

