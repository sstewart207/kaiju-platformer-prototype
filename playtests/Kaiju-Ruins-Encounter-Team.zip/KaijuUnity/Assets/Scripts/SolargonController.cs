using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(CharacterController))]
public sealed class SolargonController : MonoBehaviour
{
    private const float RunSpeed = 4.45f;
    private const float AirMoveSpeed = 5.2f;
    private const float DashSpeed = 17f;
    private const float JumpSpeed = 8.6f;
    private const float CoyoteTime = .11f;
    private const float JumpBufferTime = .13f;
    private const float DefaultPitch = 25f;
    private const float CameraDistance = 6.7f;

    [SerializeField] private Transform visual;
    [SerializeField] private Transform cameraPivot;
    [SerializeField] private Camera followCamera;
    [SerializeField] private Transform finish;
    [SerializeField] private RuinsEncounter encounter;
    private CharacterController capsule;
    private Transform[] legs;
    private Quaternion[] legRest;
    private Transform[] wings;
    private Quaternion[] wingRest;
    private Transform tail;
    private KaijuGait gait;
    private Quaternion tailRest;
    private Vector3 spawn;
    private Vector3 horizontal;
    private Vector3 dashDirection;
    private float vertical;
    private float dashRemaining;
    private float dashCooldown;
    private float jumpBuffer;
    private float coyoteRemaining;
    private float stride;
    private float yaw;
    private float pitch = DefaultPitch;
    private float manualCameraRemaining;
    private float cameraDistance = CameraDistance;
    private float facingVelocity;
    private float manualYawRate;
    private float manualPitchRate;
    private float autoYawRate;
    private float tailDrag;
    private bool autoCenterPending;
    private bool snapCamera = true;
    private bool paused;
    private bool finished;

    public void Configure(Transform model, Transform pivot, Camera camera, Transform finishGate)
    {
        visual = model;
        cameraPivot = pivot;
        followCamera = camera;
        finish = finishGate;
    }

    public void ConfigureEncounter(RuinsEncounter slice) => encounter = slice;

    private void Awake()
    {
        capsule = GetComponent<CharacterController>();
        spawn = transform.position;
        gait = visual.GetComponent<KaijuGait>();
        legs = gait == null ? FindPivots("Leg_", out legRest) : System.Array.Empty<Transform>();
        wings = FindPivots("Wing_", out wingRest);
        foreach (var descendant in visual.GetComponentsInChildren<Transform>())
        {
            if (descendant.name == "Tail")
            {
                tail = descendant;
                tailRest = tail.localRotation;
                break;
            }
        }
    }

    private Transform[] FindPivots(string prefix, out Quaternion[] rest)
    {
        var pivots = System.Array.FindAll(visual.GetComponentsInChildren<Transform>(),
            item => item.name.StartsWith(prefix) && item.GetComponent<MeshFilter>() == null);
        rest = System.Array.ConvertAll(pivots, item => item.localRotation);
        return pivots;
    }

    private void Update()
    {
        var keys = Keyboard.current;
        var pad = Gamepad.current;
        if ((keys?.rKey.wasPressedThisFrame ?? false) ||
            (pad?.buttonNorth.wasPressedThisFrame ?? false) || transform.position.y < -3)
            ResetPlayer();

        if ((keys?.escapeKey.wasPressedThisFrame ?? false) || (pad?.startButton.wasPressedThisFrame ?? false))
            paused = !paused;
        if (paused || finished)
            return;

        var move = pad?.leftStick.ReadValue() ?? Vector2.zero;
        if (move.sqrMagnitude < .0256f)
            move = pad?.dpad.ReadValue() ?? Vector2.zero;
        if (keys != null)
        {
            var keyMove = new Vector2(
                Axis(keys.dKey.isPressed || keys.rightArrowKey.isPressed, keys.aKey.isPressed || keys.leftArrowKey.isPressed),
                Axis(keys.wKey.isPressed || keys.upArrowKey.isPressed, keys.sKey.isPressed || keys.downArrowKey.isPressed));
            if (keyMove != Vector2.zero)
                move = keyMove.normalized;
        }
        float dt = Time.deltaTime;
        UpdateOrbit(keys, pad, move, dt);
        var basis = Quaternion.Euler(0, yaw, 0);
        Vector3 direction = Vector3.ClampMagnitude(basis * new Vector3(move.x, 0, move.y), 1);

        bool grounded = capsule.isGrounded && vertical <= 0;
        float previousHeading = transform.eulerAngles.y;

        bool jump = (keys?.spaceKey.wasPressedThisFrame ?? false) || (pad?.buttonSouth.wasPressedThisFrame ?? false);
        bool held = (keys?.spaceKey.isPressed ?? false) || (pad?.buttonSouth.isPressed ?? false);
        bool dash = (keys?.leftShiftKey.wasPressedThisFrame ?? false) ||
            (pad?.buttonWest.wasPressedThisFrame ?? false) || (pad?.rightShoulder.wasPressedThisFrame ?? false);
        dashCooldown = Mathf.Max(0, dashCooldown - dt);
        if (dash && dashCooldown <= 0)
        {
            dashDirection = direction.sqrMagnitude > .01f ? direction.normalized : transform.forward;
            dashRemaining = .16f;
            dashCooldown = .30f;
            transform.rotation = Quaternion.LookRotation(dashDirection);
            facingVelocity = 0;
        }

        jumpBuffer = jump ? JumpBufferTime : Mathf.Max(0, jumpBuffer - dt);
        coyoteRemaining = grounded ? CoyoteTime : Mathf.Max(0, coyoteRemaining - dt);
        if (jumpBuffer > 0 && coyoteRemaining > 0)
        {
            vertical = JumpSpeed;
            coyoteRemaining = jumpBuffer = 0;
        }
        else if (grounded)
        {
            vertical = -2.5f;
        }
        if (!grounded || vertical > 0)
            vertical = Mathf.Max(-22, vertical - (vertical > 0 ? (held ? 21 : 48) : 27) * dt);

        Steer(direction, grounded, dt);
        float dashStep = Mathf.Clamp(dashRemaining, 0, dt);
        if (direction.sqrMagnitude > .01f && dashStep == 0)
        {
            float targetHeading = Mathf.Atan2(direction.x,direction.z) * Mathf.Rad2Deg;
            float heading = Mathf.SmoothDampAngle(previousHeading, targetHeading, ref facingVelocity,
                grounded ? .091f : .125f, grounded ? 780f : 590f, dt);
            transform.rotation = Quaternion.Euler(0,heading,0);
        }
        else
        {
            facingVelocity = 0;
        }
        Vector3 travel = horizontal * (dt - dashStep) + dashDirection * DashSpeed * dashStep;
        dashRemaining = Mathf.Max(0, dashRemaining - dt);
        var origin = transform.position;
        var collisions = capsule.Move(travel + Vector3.up * (vertical * dt));
        if ((collisions & CollisionFlags.Above) != 0 && vertical > 0)
            vertical = 0;

        var actualMove = transform.position - origin;
        actualMove.y = 0;
        if (encounter != null && encounter.Tick(origin, transform.position, dashStep > 0, dt))
        {
            ResetPlayer();
            return;
        }
        float yawRate = dashStep > 0 ? 0 :
            Mathf.DeltaAngle(previousHeading,transform.eulerAngles.y) / Mathf.Max(.001f,dt);
        Animate(actualMove / Mathf.Max(.001f, dt), dashStep > 0, yawRate, dt);
        if ((encounter == null || encounter.Cleared) &&
            Vector3.Distance(finish.position, transform.position + Vector3.up) < 1.4f)
            finished = true;
    }

    private void Steer(Vector3 input, bool grounded, float dt)
    {
        float speed = horizontal.magnitude;
        float cap = grounded ? RunSpeed : AirMoveSpeed;
        float acceleration = grounded ? 54f : 29f;
        if (input.sqrMagnitude < .001f)
        {
            horizontal = Vector3.MoveTowards(horizontal, Vector3.zero, (grounded ? 81f : 10f) * dt);
            return;
        }
        if (speed < .24f || dashRemaining > 0)
        {
            horizontal = Vector3.MoveTowards(horizontal,input*cap,acceleration*dt);
            return;
        }

        Vector3 wanted = input.normalized;
        Vector3 current = horizontal / speed;
        float alignment = Vector3.Dot(current,wanted);
        // When doubling back, brake before pushing off in the opposite direction.
        if (grounded && alignment < -.86f)
        {
            horizontal = Vector3.MoveTowards(horizontal,Vector3.zero,50f*dt);
            return;
        }
        float turnDegrees = grounded ? Mathf.Lerp(700,450,Mathf.Clamp01(speed/RunSpeed)) : 405;
        Vector3 tangent = Vector3.RotateTowards(current,wanted,turnDegrees*Mathf.Deg2Rad*dt,0);
        float cornerSpeed = grounded ? Mathf.Lerp(.72f,1f,Mathf.InverseLerp(-1,.65f,alignment)) : 1f;
        speed = Mathf.MoveTowards(speed,cap*input.magnitude*cornerSpeed,acceleration*dt);
        horizontal = tangent.normalized * speed;
    }

    private void UpdateOrbit(Keyboard keys, Gamepad pad, Vector2 move, float dt)
    {
        var look = pad?.rightStick.ReadValue() ?? Vector2.zero;
        if (look.sqrMagnitude < .0256f)
            look = Vector2.zero;
        if (keys != null)
            look.x += Axis(keys.eKey.isPressed, keys.qKey.isPressed);
        bool mouseOrbit = Mouse.current?.rightButton.isPressed ?? false;
        if (mouseOrbit)
        {
            Vector2 mouse = Mouse.current.delta.ReadValue();
            yaw += mouse.x * .22f;
            pitch -= mouse.y * .15f;
        }
        float orbitBlend = 1 - Mathf.Exp(-20f*dt);
        manualYawRate = Mathf.Lerp(manualYawRate,Mathf.Clamp(look.x,-1,1)*155f,orbitBlend);
        manualPitchRate = Mathf.Lerp(manualPitchRate,look.y*94f,orbitBlend);
        yaw += manualYawRate * dt;
        pitch = Mathf.Clamp(pitch - manualPitchRate * dt, 10, 54);
        if ((keys?.cKey.wasPressedThisFrame ?? false) || (pad?.rightStickButton.wasPressedThisFrame ?? false))
        {
            yaw = transform.eulerAngles.y;
            pitch = DefaultPitch;
            autoCenterPending = false;
            manualYawRate = manualPitchRate = autoYawRate = 0;
            return;
        }
        if (mouseOrbit || look != Vector2.zero)
        {
            manualCameraRemaining = 1.35f;
            autoCenterPending = false;
            autoYawRate = 0;
            return;
        }
        manualCameraRemaining = Mathf.Max(0, manualCameraRemaining - dt);
        if (manualCameraRemaining > 0 || !capsule.isGrounded || dashRemaining > 0)
            return;
        float turn = Mathf.DeltaAngle(yaw, transform.eulerAngles.y);
        if (move.sqrMagnitude > .12f)
            autoCenterPending |= Mathf.Abs(turn) > 24f;
        // Turning the camera during a sustained side input would also turn the movement axis.
        if (autoCenterPending && move.sqrMagnitude < .015f)
        {
            autoYawRate = Mathf.Lerp(autoYawRate,Mathf.Clamp(turn*3.2f,-105f,105f),1-Mathf.Exp(-13f*dt));
            yaw += Mathf.Sign(turn) * Mathf.Min(Mathf.Abs(turn),Mathf.Abs(autoYawRate*dt));
            autoCenterPending = Mathf.Abs(turn) > 3f;
        }
        else
        {
            autoYawRate = 0;
        }
    }

    private void Animate(Vector3 velocity, bool dashing, float yawRate, float dt)
    {
        if (gait != null)
            gait.UpdatePose(velocity, RunSpeed, capsule.isGrounded, vertical, dashing, yawRate, dt);
        float speed = velocity.magnitude;
        float movement = Mathf.InverseLerp(0, RunSpeed, speed);
        stride += dt * (2f + 8.5f * movement);
        for (int i = 0; i < legs.Length; i++)
        {
            bool phase = legs[i].name.Contains("_Mid") ^ legs[i].name.Contains("_L_");
            float angle = capsule.isGrounded ? Mathf.Sin(stride + (phase ? Mathf.PI : 0)) * 18 * movement : -11;
            legs[i].localRotation = Quaternion.AngleAxis(angle, Vector3.right) * legRest[i];
        }
        for (int i = 0; i < wings.Length; i++)
        {
            float sign = wings[i].name.Contains("_L_") ? 1 : -1;
            float angle = Mathf.Sin(stride * .43f + (wings[i].name.EndsWith("Rear") ? .6f : 0)) * (2 + 2.5f * movement);
            wings[i].localRotation = Quaternion.AngleAxis(sign * angle, Vector3.forward) * wingRest[i];
        }
        tailDrag = Mathf.Lerp(tailDrag,Mathf.Clamp(-yawRate*.028f,-15f,15f),1-Mathf.Exp(-11f*dt));
        if (tail != null)
            tail.localRotation = Quaternion.AngleAxis(tailDrag + Mathf.Sin(stride*.55f)*(3+4*movement),Vector3.up) * tailRest;
    }

    private void LateUpdate()
    {
        var orbit = Quaternion.Euler(pitch, yaw, 0);
        var anchor = transform.position + Vector3.up * 1.42f;
        float dt = Time.deltaTime;
        var pivot = cameraPivot.position;
        pivot.x = Mathf.Lerp(pivot.x, anchor.x, 1 - Mathf.Exp(-15 * dt));
        pivot.z = Mathf.Lerp(pivot.z, anchor.z, 1 - Mathf.Exp(-15 * dt));
        pivot.y = Mathf.Lerp(pivot.y, anchor.y, 1 - Mathf.Exp(-(capsule.isGrounded ? 13 : 8) * dt));
        pivot = anchor + Vector3.ClampMagnitude(pivot - anchor, .68f);
        int collisionMask = ~(1 << gameObject.layer);
        if (snapCamera || Physics.Linecast(anchor, pivot, collisionMask, QueryTriggerInteraction.Ignore))
            pivot = anchor;
        cameraPivot.position = pivot;

        Vector3 back = orbit * Vector3.back;
        float available = CameraDistance;
        if (Physics.SphereCast(pivot, .28f, back, out var hit, CameraDistance,
                collisionMask, QueryTriggerInteraction.Ignore))
            available = Mathf.Max(.08f, hit.distance - .06f);
        cameraDistance = snapCamera || available < cameraDistance ? available :
            Mathf.MoveTowards(cameraDistance, available, 8f * dt);
        followCamera.transform.SetPositionAndRotation(pivot + back * cameraDistance, orbit);
        snapCamera = false;
    }

    private void ResetPlayer()
    {
        capsule.enabled = false;
        transform.SetPositionAndRotation(spawn, Quaternion.identity);
        capsule.enabled = true;
        horizontal = Vector3.zero;
        vertical = dashRemaining = dashCooldown = yaw = 0;
        jumpBuffer = coyoteRemaining = manualCameraRemaining = 0;
        facingVelocity = manualYawRate = manualPitchRate = autoYawRate = tailDrag = 0;
        pitch = DefaultPitch;
        autoCenterPending = false;
        snapCamera = true;
        if (gait != null) gait.ResetPose();
        if (encounter != null) encounter.Restart();
        paused = finished = false;
    }

    private void OnGUI()
    {
        if (paused || finished)
            GUI.Box(new Rect((Screen.width - 240) / 2f, 32, 240, 40),
                finished ? "Course complete   ·   R / △ Replay" : "Paused   ·   Esc / Options Resume");
    }

    private static float Axis(bool positive, bool negative) => (positive ? 1 : 0) - (negative ? 1 : 0);
}

