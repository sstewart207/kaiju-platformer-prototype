using UnityEngine;

public sealed class RuinsEncounter : MonoBehaviour
{
    [SerializeField] private CharacterController enemy;
    [SerializeField] private GameObject gate;
    [SerializeField] private Transform[] arms;
    private Vector3 home;
    private float time;
    private float windup;
    private float recovery;
    private bool attacking;
    public bool Cleared { get; private set; }

    public void Configure(CharacterController zombie, GameObject barrier, Transform[] armPivots)
    {
        enemy = zombie;
        gate = barrier;
        arms = armPivots;
    }

    private void Awake() => home = enemy.transform.position;

    public bool Tick(Vector3 before, Vector3 player, bool dash, float dt)
    {
        if (Cleared) return false;
        var target = enemy.transform.position;
        Vector3 toPlayer = player - target;
        bool onArena = player.z > 10 && player.z < 23 && player.x > -2.5f && player.x < 2.5f;
        bool sameHeight = Mathf.Abs(toPlayer.y) < .8f;
        toPlayer.y = 0;
        if (dash && sameHeight && onArena && PassesEnemy(before, player, target))
        {
            Cleared = true;
            enemy.gameObject.SetActive(false);
            gate.SetActive(false);
            return false;
        }

        time += dt;
        recovery = Mathf.Max(0,recovery-dt);
        float pose = attacking ? -112 : recovery > .62f ? -80 : -32;
        foreach (var arm in arms)
            arm.localRotation = Quaternion.RotateTowards(arm.localRotation,Quaternion.Euler(pose,0,0),400*dt);
        if (attacking)
        {
            windup -= dt;
            if (windup > 0) return false;
            attacking = false;
            recovery = .8f;
            return onArena && sameHeight && !dash && toPlayer.sqrMagnitude < .95f*.95f &&
                !Physics.Linecast(target+Vector3.up*.68f, player+Vector3.up*.68f, ~4, QueryTriggerInteraction.Ignore);
        }
        bool chase = onArena && sameHeight && toPlayer.sqrMagnitude < 25;
        if (chase && recovery == 0 && toPlayer.sqrMagnitude < 1.1f*1.1f)
        {
            attacking = true;
            windup = .42f;
            return false;
        }

        var goal = chase ? player : home + Vector3.right * (Mathf.Sin(time*.75f)*1.25f);
        goal.x = Mathf.Clamp(goal.x, -1.75f, 1.75f);
        goal.z = Mathf.Clamp(goal.z, 13, 21.75f);
        var travel = goal - target;
        travel.y = 0;
        if (travel.sqrMagnitude > .02f)
            enemy.transform.rotation = Quaternion.RotateTowards(enemy.transform.rotation,
                Quaternion.LookRotation(travel), 340*dt);
        enemy.Move(Vector3.ClampMagnitude(travel,(chase ? 1.85f : 1.05f)*dt) + Vector3.down*(3*dt));
        return false;
    }

    private static bool PassesEnemy(Vector3 before, Vector3 after, Vector3 target)
    {
        before.y = after.y = target.y;
        var travel = after-before;
        float fraction = Mathf.Clamp01(Vector3.Dot(target-before,travel)/Mathf.Max(.0001f,travel.sqrMagnitude));
        var nearest = before + fraction*travel;
        return (target-nearest).sqrMagnitude <= .83f*.83f &&
            !Physics.Linecast(nearest+Vector3.up*.68f,target+Vector3.up*.68f,~4,QueryTriggerInteraction.Ignore);
    }

    public void Restart()
    {
        enemy.gameObject.SetActive(true);
        enemy.enabled = false;
        enemy.transform.SetPositionAndRotation(home,Quaternion.Euler(0,180,0));
        enemy.enabled = true;
        time = windup = recovery = 0;
        attacking = Cleared = false;
        gate.SetActive(true);
    }

    private void OnGUI()
    {
        GUI.Box(new Rect(12,12,110,26),Cleared ? "Zombies 1 / 1" : "Zombies 0 / 1");
    }
}

