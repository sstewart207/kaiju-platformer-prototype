using System;
using UnityEngine;

public sealed class KaijuGait : MonoBehaviour
{
    [Serializable]
    public sealed class Leg
    {
        public Transform hip;
        public Transform knee;
        public Transform ankle;
        [Range(0,1)] public float phase;
        public float soleHeight;
        [NonSerialized] public Quaternion hipRest, kneeRest, footRest;
        [NonSerialized] public Vector3 point, start, planted;
        [NonSerialized] public bool swinging, initialized;
    }

    [SerializeField] private Transform body;
    [SerializeField] private Leg[] legs;
    [SerializeField] private ParticleSystem dust;
    [SerializeField, Min(.25f)] private float strideLength = 1.24f;
    [SerializeField, Min(0)] private float forwardReach = .26f;
    [SerializeField, Range(.25f,.70f)] private float swingFraction = .34f;
    private Vector3 bodyRest;
    private Quaternion bodyRotationRest;
    private float cycle;
    private float crouch;
    private float landing;
    private float bank;
    private bool lastGrounded;
    private int floorMask;

    public void Configure(Transform model, Leg[] joints, ParticleSystem dustSystem)
    {
        body = model;
        legs = joints;
        dust = dustSystem;
    }

    private void Awake()
    {
        bodyRest = body.localPosition;
        bodyRotationRest = body.localRotation;
        floorMask = ~(1 << transform.root.gameObject.layer);
        foreach (var leg in legs)
        {
            leg.hipRest = leg.hip.localRotation;
            leg.kneeRest = leg.knee.localRotation;
            leg.footRest = leg.ankle.localRotation;
        }
    }

    public void ResetPose()
    {
        cycle = crouch = landing = bank = 0;
        lastGrounded = false;
        dust.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
        body.localPosition = bodyRest;
        body.localRotation = bodyRotationRest;
        foreach (var leg in legs)
        {
            leg.initialized = leg.swinging = false;
            Restore(leg);
        }
    }

    public void UpdatePose(Vector3 velocity, float runSpeed, bool grounded, float vertical, bool dashing,
        float yawRate, float dt)
    {
        float speed = velocity.magnitude;
        float effort = Mathf.Clamp01(speed / runSpeed);
        bool running = grounded && !dashing && speed > .24f;
        float cadence = Mathf.Min(4f, speed / strideLength);
        if (running)
            cycle = Mathf.Repeat(cycle + cadence * dt, 1);
        bool touchdown = grounded && !lastGrounded && vertical < -2.6f;
        if (touchdown)
            landing = Mathf.Clamp01(-vertical / 10);
        landing = Mathf.MoveTowards(landing, 0, dt * 5.6f);
        float bodyDrop = running ? .155f * effort : 0;
        bodyDrop += landing * .13f;
        crouch = Mathf.Lerp(crouch, bodyDrop, 1 - Mathf.Exp(-20 * dt));
        body.localPosition = bodyRest - Vector3.up * crouch;
        float lean = running ? Mathf.Clamp(-yawRate*.018f,-7f,7f)*effort : 0;
        bank = Mathf.Lerp(bank,lean,1-Mathf.Exp(-16f*dt));
        var roll = Quaternion.AngleAxis(bank,Vector3.forward);
        body.localRotation = roll * bodyRotationRest;
        var unrollFoot = transform.rotation * Quaternion.Inverse(roll) * Quaternion.Inverse(transform.rotation);

        foreach (var leg in legs)
        {
            Restore(leg);
            Vector3 ankleRest = leg.ankle.position;
            Quaternion footOrientation = leg.ankle.rotation;
            // Lower the hips without lowering the feet's neutral place on the ground.
            Vector3 neutral = ankleRest + transform.up * crouch;
            Vector3 target;
            bool footfall = false;
            if (!grounded || dashing)
            {
                float tuck = vertical > .5f || dashing ? .16f : .035f;
                target = ankleRest + transform.up * tuck +
                    transform.forward * (leg.phase < .25f ? .09f : -.065f);
                leg.point = leg.initialized
                    ? Vector3.Lerp(leg.point + velocity * dt, target, 1 - Mathf.Exp(-26 * dt))
                    : target;
                leg.swinging = false;
            }
            else
            {
                float step = Mathf.Repeat(cycle + leg.phase, 1);
                if (!leg.initialized || !lastGrounded)
                {
                    leg.point = GroundPoint(neutral, leg.soleHeight);
                    leg.planted = leg.point;
                    leg.swinging = false;
                }
                if (!running)
                {
                    leg.planted = Vector3.MoveTowards(leg.point, GroundPoint(neutral, leg.soleHeight), 2.65f * dt);
                    leg.point = leg.planted;
                    leg.swinging = false;
                }
                else if (step < swingFraction)
                {
                    if (!leg.swinging) leg.start = leg.point;
                    float t = step / swingFraction;
                    float eased = t * t * (3 - 2 * t);
                    // Aim from where the hips will be at contact so the target stays still at a steady pace.
                    float swingTimeLeft = (swingFraction - step) / cadence;
                    var nextStep = neutral + velocity * swingTimeLeft + velocity.normalized * (forwardReach * effort);
                    Vector3 next = GroundPoint(nextStep, leg.soleHeight);
                    leg.point = Vector3.Lerp(leg.start, next, eased) +
                        transform.up * (Mathf.Sin(t * Mathf.PI) * (.032f + .040f * effort));
                    leg.planted = next;
                    leg.swinging = true;
                }
                else
                {
                    footfall = leg.swinging;
                    leg.point = leg.planted;
                    leg.swinging = false;
                }
            }

            if (grounded && !dashing)
                footOrientation = unrollFoot * footOrientation;
            Solve(leg, leg.point, footOrientation);
            if (footfall || touchdown)
                EmitDust(leg.ankle.position, leg.soleHeight, velocity, touchdown);
            leg.initialized = true;
        }
        lastGrounded = grounded;
    }

    private Vector3 GroundPoint(Vector3 target, float soleHeight)
    {
        if (Physics.Raycast(target + Vector3.up * .36f, Vector3.down, out var floor,
                .83f, floorMask, QueryTriggerInteraction.Ignore))
        {
            // Ankle centers sit above the sole. A higher surface can catch the next step.
            target.y = floor.point.y + soleHeight + .006f;
        }
        return target;
    }

    private void EmitDust(Vector3 foot, float soleHeight, Vector3 velocity, bool landingDust)
    {
        if (!Physics.Raycast(foot + Vector3.up * .13f, Vector3.down, out var floor,
                soleHeight + .22f, floorMask, QueryTriggerInteraction.Ignore))
            return;
        if (!dust.isPlaying) dust.Play();
        int count = landingDust ? 4 : 3;
        for (int i = 0; i < count; i++)
        {
            Vector2 spread = UnityEngine.Random.insideUnitCircle;
            var sideways = new Vector3(spread.x,0,spread.y);
            var puff = new ParticleSystem.EmitParams
            {
                position = floor.point + Vector3.up * .07f + sideways * .065f,
                velocity = sideways * .43f + Vector3.up * (.32f + spread.sqrMagnitude * .34f)
                    - velocity * .038f,
                startColor = new Color(.79f,.64f,.47f,.67f),
                startLifetime = .25f + spread.sqrMagnitude * .21f,
                startSize = .19f + spread.sqrMagnitude * .21f
            };
            dust.Emit(puff,1);
        }
    }

    private static void Restore(Leg leg)
    {
        leg.hip.localRotation = leg.hipRest;
        leg.knee.localRotation = leg.kneeRest;
        leg.ankle.localRotation = leg.footRest;
    }

    private void Solve(Leg leg, Vector3 target, Quaternion footOrientation)
    {
        Vector3 hip = leg.hip.position, knee = leg.knee.position, foot = leg.ankle.position;
        Vector3 line = target - hip;
        if (line.sqrMagnitude < .00001f) return;
        float upper = Vector3.Distance(hip,knee), lower = Vector3.Distance(knee,foot);
        var direction = line.normalized;
        float distance = Mathf.Clamp(line.magnitude, Mathf.Abs(upper-lower) + .001f, upper+lower-.001f);
        float along = (upper*upper + distance*distance - lower*lower) / (2*distance);
        float bend = Mathf.Sqrt(Mathf.Max(0,upper*upper - along*along));

        Vector3 pole = Vector3.ProjectOnPlane(knee - Vector3.Lerp(hip, foot, .50f), direction);
        if (pole.sqrMagnitude < .0025f)
            pole = Vector3.ProjectOnPlane(transform.forward, direction);
        var bendPoint = hip + direction * along + pole.normalized * bend;
        leg.hip.rotation = Quaternion.FromToRotation(knee - hip, bendPoint - hip) * leg.hip.rotation;
        leg.knee.rotation = Quaternion.FromToRotation(leg.ankle.position - leg.knee.position,
            hip + direction * distance - leg.knee.position) * leg.knee.rotation;
        leg.ankle.rotation = footOrientation;
    }
}

