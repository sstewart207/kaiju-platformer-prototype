using System;
using System.Linq;
using UnityEditor;
using UnityEngine;

public static class SolargonRigBuilder
{
    private const string Folder = "Assets/Models/SolargonRig";
    public const string PrefabPath = Folder + "/Solargon Visual.prefab";

    public static void Prepare(GameObject instance, Transform visual)
    {
        if (!AssetDatabase.IsValidFolder(Folder))
            AssetDatabase.CreateFolder("Assets/Models", "SolargonRig");
        PrefabUtility.UnpackPrefabInstance(instance, PrefabUnpackMode.Completely, InteractionMode.AutomatedAction);
        SolargonProportions.Apply(instance.transform, visual);
        foreach (Transform middle in instance.GetComponentsInChildren<Transform>()
                     .Where(item => item.name == "Leg_L_Mid" || item.name == "Leg_R_Mid").ToArray())
            UnityEngine.Object.DestroyImmediate(middle.gameObject);
        var hips = instance.GetComponentsInChildren<Transform>()
            .Where(item => item.name.StartsWith("Leg_") && item.GetComponent<MeshFilter>() == null)
            .ToArray();
        var joints = hips.Select(item => BuildLeg(item, visual)).ToArray();
        if (joints.Length != 4)
            throw new InvalidOperationException($"This Solargon variant requires four legs. Found {joints.Length}.");
        var gait = visual.gameObject.AddComponent<KaijuGait>();
        gait.Configure(instance.transform, joints, CreateDust(visual));
    }

    private static KaijuGait.Leg BuildLeg(Transform hip, Transform visual)
    {
        var parts = hip.Cast<Transform>().ToArray();
        var foreleg = parts.Single(part => part.name.EndsWith("foreleg"));
        var paw = parts.Single(part => part.name.EndsWith("paw"));
        var lowerParts = parts.Where(part => part == paw || part.name.Contains("talon")).ToArray();
        bool rear = hip.name.EndsWith("_Rear");
        var kneePoint = Vector3.Lerp(hip.position, paw.position, .48f) - visual.forward * (rear ? .12f : .105f);
        Transform knee = Joint("Knee", hip, kneePoint);
        Transform ankle = Joint("Ankle", knee, paw.position);
        float floor = lowerParts.Min(part => part.GetComponent<MeshRenderer>().bounds.min.y);
        foreach (Transform part in lowerParts)
            part.SetParent(ankle, true);
        foreach (Transform part in parts.Where(part => part.name.EndsWith("armor")))
            part.SetParent(knee, true);
        CreateSkin(foreleg, hip, knee, ankle);

        return new KaijuGait.Leg
        {
            hip = hip,
            knee = knee,
            ankle = ankle,
            // Right hind, right front, left hind, left front.
            phase = rear
                ? (hip.name.Contains("_L_") ? .50f : 0)
                : (hip.name.Contains("_L_") ? .25f : .75f),
            soleHeight = ankle.position.y - floor
        };
    }

    private static Transform Joint(string name, Transform parent, Vector3 at)
    {
        Transform joint = new GameObject(name).transform;
        joint.SetParent(parent, false);
        joint.position = at;
        return joint;
    }

    private static void CreateSkin(Transform foreleg, Transform hip, Transform knee, Transform ankle)
    {
        var filter = foreleg.GetComponent<MeshFilter>();
        var rigid = foreleg.GetComponent<MeshRenderer>();
        var mesh = UnityEngine.Object.Instantiate(filter.sharedMesh);
        mesh.name = hip.name + " skin";
        mesh.bindposes = new[]
        {
            hip.worldToLocalMatrix * foreleg.localToWorldMatrix,
            knee.worldToLocalMatrix * foreleg.localToWorldMatrix
        };
        var vertices = mesh.vertices;
        Vector3 axis = (ankle.position - hip.position).normalized;
        float pivot = Vector3.Dot(knee.position - hip.position, axis);
        var weights = new BoneWeight[vertices.Length];
        for (int i = 0; i < vertices.Length; i++)
        {
            Vector3 point = foreleg.TransformPoint(vertices[i]);
            float distance = Vector3.Dot(point - hip.position, axis);
            float shin = Mathf.InverseLerp(pivot - .045f, pivot + .045f, distance);
            weights[i] = new BoneWeight
            {
                boneIndex0 = shin < .5f ? 0 : 1,
                boneIndex1 = shin < .5f ? 1 : 0,
                weight0 = Mathf.Max(shin,1-shin),
                weight1 = Mathf.Min(shin,1-shin)
            };
        }
        mesh.boneWeights = weights;
        var materials = rigid.sharedMaterials;
        UnityEngine.Object.DestroyImmediate(rigid);
        UnityEngine.Object.DestroyImmediate(filter);
        var skin = foreleg.gameObject.AddComponent<SkinnedMeshRenderer>();
        skin.sharedMesh = StoreMesh(mesh);
        skin.sharedMaterials = materials;
        skin.rootBone = hip;
        skin.bones = new[] {hip, knee};
        skin.localBounds = new Bounds(Vector3.zero,Vector3.one * 4);
    }

    private static Mesh StoreMesh(Mesh mesh)
    {
        string path = $"{Folder}/{mesh.name}.asset";
        var saved = AssetDatabase.LoadAssetAtPath<Mesh>(path);
        if (saved == null)
        {
            AssetDatabase.CreateAsset(mesh,path);
            return mesh;
        }
        EditorUtility.CopySerialized(mesh,saved);
        EditorUtility.SetDirty(saved);
        UnityEngine.Object.DestroyImmediate(mesh);
        return saved;
    }

    private static ParticleSystem CreateDust(Transform visual)
    {
        var obj = new GameObject("Footfall dust");
        obj.transform.SetParent(visual,false);
        var dust = obj.AddComponent<ParticleSystem>();
        var main = dust.main;
        main.loop = false;
        main.playOnAwake = false;
        main.simulationSpace = ParticleSystemSimulationSpace.World;
        main.maxParticles = 240;
        main.gravityModifier = .045f;
        var emission = dust.emission;
        emission.enabled = false;
        var shape = dust.shape;
        shape.enabled = false;
        var colors = dust.colorOverLifetime;
        colors.enabled = true;
        var fade = new Gradient();
        fade.SetKeys(new[] {new GradientColorKey(Color.white,0),new GradientColorKey(Color.white,1)},
            new[] {new GradientAlphaKey(.78f,0),new GradientAlphaKey(.5f,.35f),new GradientAlphaKey(0,1)});
        colors.color = fade;
        var size = dust.sizeOverLifetime;
        size.enabled = true;
        size.size = new ParticleSystem.MinMaxCurve(1.55f,AnimationCurve.Linear(0,.45f,1,1));
        var renderer = obj.GetComponent<ParticleSystemRenderer>();
        var path = Folder + "/Footfall dust.mat";
        var material = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (material == null)
        {
            material = new Material(Shader.Find("Kaiju/Footfall Dust"));
            AssetDatabase.CreateAsset(material,path);
        }
        renderer.sharedMaterial = material;
        return dust;
    }
}

