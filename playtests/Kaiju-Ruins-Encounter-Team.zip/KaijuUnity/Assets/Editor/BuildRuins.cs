using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class BuildRuins
{
    private const string ModelPath = "Assets/Models/Solargon.fbx";
    private const string ScenePath = "Assets/Scenes/Ruins.unity";

    [MenuItem("Kaiju/Rebuild Ruins Prototype")]
    public static void Create()
    {
        var asset = AssetDatabase.LoadAssetAtPath<GameObject>(ModelPath);
        if (asset == null)
            throw new InvalidOperationException("Solargon FBX import is required.");
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        Directory.CreateDirectory("Assets/Scenes");
        Directory.CreateDirectory("Assets/Materials");
        AssetDatabase.Refresh();

        var shader = Shader.Find("Standard");
        if (shader == null)
            throw new InvalidOperationException("Built-in Standard shader is required.");
        var grass = MakeMaterial("Moss", "537C54", shader);
        var path = MakeMaterial("Sandstone", "C3A671", shader);
        var stone = MakeMaterial("Ruins", "8C8066", shader);
        var cap = MakeMaterial("Trim", "DAC794", shader);
        var brass = MakeMaterial("Sun Gate", "D18429", shader);
        var leaf = MakeMaterial("Canopy", "386954", shader);
        var trunk = MakeMaterial("Bark", "5D4931", shader);

        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
        RenderSettings.ambientLight = new Color(.50f, .56f, .55f);
        RenderSettings.fog = true;
        RenderSettings.fogColor = new Color(.49f,.70f,.69f);
        RenderSettings.fogMode = FogMode.Linear;
        RenderSettings.fogStartDistance = 20;
        RenderSettings.fogEndDistance = 50;
        var sun = new GameObject("Sun").AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.color = new Color(1, .88f, .70f);
        sun.intensity = .95f;
        sun.shadows = LightShadows.Soft;
        sun.transform.rotation = Quaternion.Euler(42, -36, 0);

        var ruins = new GameObject("Ruins").transform;
        Block("Solid ground", new Vector3(0,-.51f,11), new Vector3(30,1,44), grass,ruins);
        Block("Walkable causeway", new Vector3(0,-.015f,9), new Vector3(5,.12f,29), path,ruins);
        for (int i = 0; i < 8; i++)
        {
            float z = i * 3.2f - .6f;
            Block("Paving", new Vector3(0,.018f,z),new Vector3(4.96f,.09f,.1f),cap,ruins);
            if (i < 6)
            {
                float x = (i % 2 == 0 ? 1 : -1) * 4.5f;
                Block("Column",new Vector3(x,1.27f,z),new Vector3(.70f,2.6f,.70f),stone,ruins);
                Block("Capital",new Vector3(x,2.55f,z),new Vector3(1.03f,.31f,1.03f),cap,ruins);
                Block("Plinth",new Vector3(x,.16f,z),new Vector3(1,.33f,1),path,ruins);
                var tree=Block("Cypress",new Vector3(-x*1.67f,1.3f,z-1.2f),new Vector3(.33f,2.6f,.35f),trunk,ruins);
                var crown=GameObject.CreatePrimitive(PrimitiveType.Sphere);
                crown.name="Cypress crown";
                crown.transform.SetParent(tree.transform.parent);
                crown.transform.position=new Vector3(-x*1.67f,2.9f,z-1.2f);
                crown.transform.localScale=new Vector3(1.4f,2.85f,1.4f);
                crown.GetComponent<Renderer>().sharedMaterial=leaf;
            }
        }
        for (int i = 0; i < 4; i++)
            Block("Jump terrace",new Vector3(-3.4f-i*1.7f,.26f+i*.25f,6+i*2.8f),
                new Vector3(2.4f,.53f+i*.5f,2.4f),stone,ruins);
        var gate = new GameObject("Finish").transform;
        gate.position = new Vector3(0,1.0f,23);
        Block("Gate left",new Vector3(-2.3f,1.55f,23),new Vector3(.55f,3.1f,.65f),cap,ruins);
        Block("Gate right",new Vector3(2.3f,1.55f,23),new Vector3(.55f,3.1f,.65f),cap,ruins);
        Block("Gate lintel",new Vector3(0,3.1f,23),new Vector3(5.1f,.48f,.7f),brass,ruins);

        var player = new GameObject("Solargon Player") { layer = 2 };
        player.transform.position = new Vector3(0,.08f,0);
        var shell = player.AddComponent<CharacterController>();
        shell.radius = .42f;
        shell.height = 1.35f;
        shell.center = new Vector3(0,.68f,0);
        shell.stepOffset = .28f;
        var visual = new GameObject("Visual");
        visual.transform.SetParent(player.transform,false);
        var model = (GameObject)PrefabUtility.InstantiatePrefab(asset,visual.transform);
        var nose = model.GetComponentsInChildren<Transform>().FirstOrDefault(node => node.name == "Nose");
        if (nose != null && visual.transform.InverseTransformPoint(nose.position).z < 0)
            model.transform.localRotation = Quaternion.Euler(0,180,0);
        var renderers = model.GetComponentsInChildren<MeshRenderer>();
        if (renderers.Length == 0)
            throw new InvalidOperationException("Solargon FBX has no renderable meshes.");
        var bounds = renderers[0].bounds;
        foreach (var renderer in renderers)
            bounds.Encapsulate(renderer.bounds);
        float scale = 1.8f / bounds.size.y;
        model.transform.localScale *= scale;
        model.transform.localPosition += Vector3.up * ((player.transform.position.y - bounds.min.y) * scale);
        SolargonRigBuilder.Prepare(model, visual.transform);
        var rig = PrefabUtility.SaveAsPrefabAsset(visual, SolargonRigBuilder.PrefabPath);
        UnityEngine.Object.DestroyImmediate(visual);
        visual = (GameObject)PrefabUtility.InstantiatePrefab(rig, player.transform);

        var pivot = new GameObject("Camera target").transform;
        var camera = new GameObject("Main Camera").AddComponent<Camera>();
        camera.tag = "MainCamera";
        camera.clearFlags = CameraClearFlags.SolidColor;
        camera.backgroundColor = RenderSettings.fogColor;
        camera.orthographic = false;
        camera.fieldOfView = 56f;
        camera.nearClipPlane = .08f;
        camera.transform.SetPositionAndRotation(new Vector3(0,4.33f,-6.07f),Quaternion.Euler(25,0,0));
        player.AddComponent<SolargonController>().Configure(visual.transform,pivot,camera,gate);

        var settings = new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/ProjectSettings.asset").First());
        var input = settings.FindProperty("activeInputHandler");
        if (input != null && input.intValue != 1)
        {
            input.intValue = 1;
            settings.ApplyModifiedPropertiesWithoutUndo();
        }
        EditorSceneManager.SaveScene(scene, ScenePath);
        EditorBuildSettings.scenes = new [] {new EditorBuildSettingsScene(ScenePath,true)};
        AssetDatabase.SaveAssets();
        Debug.Log($"KAIJU_VALIDATION meshes={renderers.Length} modelHeight={bounds.size.y:F2} scene={ScenePath}");
    }

    private static Material MakeMaterial(string name,string hex, Shader shader)
    {
        string path = $"Assets/Materials/{name}.mat";
        var material = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (material == null)
        {
            material = new Material(shader);
            AssetDatabase.CreateAsset(material,path);
        }
        ColorUtility.TryParseHtmlString("#"+hex,out var color);
        material.color = color;
        material.SetFloat("_Glossiness", .08f);
        EditorUtility.SetDirty(material);
        return material;
    }

    private static GameObject Block(string name,Vector3 position,Vector3 size,Material material,Transform parent)
    {
        var block=GameObject.CreatePrimitive(PrimitiveType.Cube);
        block.name=name;
        block.transform.SetParent(parent);
        block.transform.position=position;
        block.transform.localScale=size;
        block.GetComponent<Renderer>().sharedMaterial=material;
        return block;
    }
}

