using System.Linq;
using UnityEngine;

/// <summary>Adjusts the imported draft to match Solargon's compact, front-heavy concept silhouette.</summary>
internal static class SolargonProportions
{
    internal static void Apply(Transform model, Transform frame)
    {
        var nodes = model.GetComponentsInChildren<Transform>();
        Transform Find(string node) => nodes.First(item => item.name == node);
        var head = Find("Head");
        head.position += frame.up * .09f - frame.forward * .085f;
        var skull = Find("Head.001");
        Resize(skull, frame, new Vector3(1.18f,1.04f,.94f));

        // Keep the cheek line broad and integrate the nostrils into the snout.
        var muzzle = Find("Muzzle");
        muzzle.position -= frame.forward * .069f;
        Resize(muzzle, frame, new Vector3(1.25f,1.13f,.67f));
        var jaw = Find("Jaw");
        jaw.position -= frame.forward * .045f;
        Resize(jaw, frame, new Vector3(1.20f,1.09f,.82f));
        var chin = Find("Chin");
        chin.position -= frame.forward * .07f;
        Resize(chin, frame, new Vector3(1.19f,1,.82f));
        var face = muzzle.GetComponent<Renderer>().bounds;
        foreach (var item in nodes.Where(item => item.name.EndsWith("nostril")))
        {
            float side = item.name.StartsWith("L") ? -1 : 1;
            item.position = face.center + frame.right * (side*.071f) +
                frame.up * .026f + frame.forward * (face.extents.z*.89f);
            Resize(item,frame,new Vector3(1.20f,.72f,.82f));
        }
        foreach (var brow in nodes.Where(item => item != null && item.name.EndsWith("swept brow")))
            brow.position -= frame.up * .022f;

        // Build the barrel chest and haunches around the existing belly and sun crest.
        foreach (string name in new[] {"Rib cage","Haunch","Throat"})
            Resize(Find(name),frame,new Vector3(1.22f,1.08f,1));
        var throat = Find("Throat");
        throat.position += frame.up * .034f;
        var haunch = Find("Haunch");
        haunch.position += frame.forward * .056f;

        foreach (Transform hip in nodes.Where(item => item != null &&
                     (item.name.EndsWith("_Front") || item.name.EndsWith("_Rear")) &&
                     item.name.StartsWith("Leg_")))
        {
            float side = Vector3.Dot(hip.position-frame.position,frame.right) < 0 ? -1 : 1;
            bool rear = hip.name.EndsWith("_Rear");
            float spread = rear ? .102f : .058f;
            hip.position += frame.right * (side*spread) + frame.forward * (rear ? -.037f : .024f);
            var parts = hip.Cast<Transform>().ToArray();
            var paw = parts.Single(part => part.name.EndsWith(" paw"));
            var lowerParts = parts.Where(part => part == paw || part.name.Contains("talon")).ToArray();
            float originalFloor = lowerParts.Min(part => part.GetComponent<Renderer>().bounds.min.y);
            var shoulder = parts.Single(part => part.name.EndsWith(" shoulder"));
            Resize(shoulder,frame,rear ? new Vector3(1.27f,1.14f,1.21f) : new Vector3(1.22f,1.15f,1.14f));
            var pawCenter = paw.position;
            Resize(paw,frame,new Vector3(1.23f,1.14f,1.12f));
            foreach (var claw in lowerParts.Where(part => part != paw))
            {
                float spreadFromPaw = Vector3.Dot(claw.position-pawCenter,frame.right);
                claw.position += frame.right * (spreadFromPaw*.23f);
                Resize(claw,frame,new Vector3(1.10f,1.05f,1.10f));
            }
            float reshapedFloor = lowerParts.Min(part => part.GetComponent<Renderer>().bounds.min.y);
            foreach (var part in lowerParts)
                part.position += frame.up * (originalFloor-reshapedFloor);
        }
        UnityEngine.Object.DestroyImmediate(Find("Nose").gameObject);
    }

    private static void Resize(Transform node, Transform frame, Vector3 factors)
    {
        // Imported FBX nodes can have a different local basis from the visible character.
        float Along(Vector3 axis) => Vector3.Scale(frame.InverseTransformDirection(axis),factors).magnitude;
        node.localScale = Vector3.Scale(node.localScale,
            new Vector3(Along(node.right),Along(node.up),Along(node.forward)));
    }
}

