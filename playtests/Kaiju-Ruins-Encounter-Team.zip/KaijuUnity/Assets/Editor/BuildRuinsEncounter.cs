using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public static class BuildRuinsEncounter
{
    public const string SlicePath = "Assets/Scenes/RuinsEncounter.unity";

    [MenuItem("Kaiju/Build Ruins Encounter")]
    public static void Create()
    {
        var scene = EditorSceneManager.OpenScene("Assets/Scenes/Ruins.unity");
        var ruins = new GameObject("Encounter layout").transform;
        var stone = AssetDatabase.LoadAssetAtPath<Material>("Assets/Materials/Ruins.mat");
        var trim = AssetDatabase.LoadAssetAtPath<Material>("Assets/Materials/Trim.mat");
        var marker = Material("Encounter marker",new Color(.25f,.65f,.68f));
        var barrierMat = Material("Encounter barrier",new Color(.59f,.25f,.11f));
        var clothes = Material("Zombie tunic",new Color(.34f,.27f,.39f));
        var skin = Material("Zombie skin",new Color(.45f,.57f,.36f));
        var boots = Material("Zombie boots",new Color(.21f,.25f,.24f));
        var eyes = Material("Zombie eyes",new Color(.98f,.69f,.22f));

        for (int i = 0; i < 3; i++)
        {
            float top = .235f+.185f*i;
            float z = 6.8f+i;
            Block("Sandstone step",new Vector3(0,top*.5f,z),new Vector3(4.95f,top,1.02f),stone,ruins);
            Block("Step lip",new Vector3(0,top-.026f,z-.40f),new Vector3(4.84f,.048f,.20f),trim,ruins,false);
        }
        Block("Raised gallery",new Vector3(0,.30f,16.8f),new Vector3(4.95f,.60f,15.02f),trim,ruins);
        Block("Step landing",new Vector3(0,.30f,8.91f),new Vector3(4.95f,.60f,1.26f),trim,ruins);
        Block("Jump stone",new Vector3(-3.26f,.21f,9.2f),new Vector3(1.4f,.44f,1.45f),stone,ruins);
        Block("Upper side landing",new Vector3(-2.96f,.40f,11.0f),new Vector3(1.10f,.82f,2f),stone,ruins);
        foreach (float x in new[] {-2.58f,2.58f})
        {
            Block("Broken gallery wall",new Vector3(x,1.02f,14),new Vector3(.30f,.85f,3.35f),stone,ruins);
            Block("Broken gallery wall",new Vector3(x,.93f,19.10f),new Vector3(.32f,.69f,2.7f),stone,ruins);
            Block("Gate marker",new Vector3(x,.85f,22.5f),new Vector3(.25f,1.7f,.25f),marker,ruins,false);
        }

        foreach (string name in new[] {"Gate left","Gate right","Gate lintel","Finish"})
            GameObject.Find(name).transform.position += Vector3.up*.60f;
        var barrier = Block("Locked sun gate",new Vector3(0,1.36f,23),new Vector3(4.05f,1.5f,.20f),barrierMat,ruins);
        for (int i = -3; i <= 3; i++)
            Block("Gate inset",new Vector3(i*.53f,1.37f,22.885f),new Vector3(.055f,1.33f,.035f),trim,ruins,false)
                .transform.SetParent(barrier.transform,true);

        var zombie = new GameObject("Ruin zombie") { layer = 2 };
        zombie.transform.SetPositionAndRotation(new Vector3(0,.62f,17),Quaternion.Euler(0,180,0));
        var capsule = zombie.AddComponent<CharacterController>();
        capsule.height = 1.66f;
        capsule.radius = .31f;
        capsule.center = Vector3.up * .84f;
        capsule.stepOffset = .15f;
        var body = zombie.transform;
        Block("Tunic",new Vector3(0,1.00f,0),new Vector3(.56f,.57f,.36f),clothes,body,false,true);
        Block("Head",new Vector3(0,1.50f,.041f),new Vector3(.39f,.41f,.34f),skin,body,false,true);
        Block("Brow",new Vector3(0,1.57f,.218f),new Vector3(.36f,.075f,.036f),boots,body,false,true);
        var arms = new Transform[2];
        for (int i = 0; i < arms.Length; i++)
        {
            float side = i == 0 ? -1 : 1;
            Block("Leg",new Vector3(side*.14f,.38f,0),new Vector3(.20f,.69f,.22f),boots,body,false,true);
            Block("Boot",new Vector3(side*.14f,.10f,.07f),new Vector3(.22f,.19f,.34f),boots,body,false,true);
            Block("Eye",new Vector3(side*.091f,1.51f,.224f),new Vector3(.066f,.041f,.042f),eyes,body,false,true);
            arms[i] = new GameObject("Arm pivot").transform;
            arms[i].SetParent(body,false);
            arms[i].localPosition = new Vector3(side*.35f,1.19f,0);
            Block("Sleeve",new Vector3(0,-.17f,0),new Vector3(.18f,.42f,.21f),clothes,arms[i],false,true);
            Block("Hand",new Vector3(0,-.39f,0),new Vector3(.15f,.18f,.17f),skin,arms[i],false,true);
        }
        var encounter = new GameObject("Zombie encounter").AddComponent<RuinsEncounter>();
        encounter.Configure(capsule,barrier,arms);
        GameObject.Find("Solargon Player").GetComponent<SolargonController>().ConfigureEncounter(encounter);

        if (!EditorSceneManager.SaveScene(scene,SlicePath))
            throw new System.InvalidOperationException("Could not save the Ruins encounter.");
        if (!System.Array.Exists(EditorBuildSettings.scenes,item => item.path == SlicePath))
        {
            var scenes = new System.Collections.Generic.List<EditorBuildSettingsScene>(EditorBuildSettings.scenes)
            {
                new EditorBuildSettingsScene(SlicePath,true)
            };
            EditorBuildSettings.scenes = scenes.ToArray();
        }
        AssetDatabase.SaveAssets();
        Debug.Log("KAIJU_ENCOUNTER_SAVED " + SlicePath);
    }

    private static Material Material(string name, Color color)
    {
        string path = $"Assets/Materials/{name}.mat";
        var asset = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (asset != null) return asset;
        asset = new Material(Shader.Find("Standard")) { color = color };
        asset.SetFloat("_Glossiness",.08f);
        AssetDatabase.CreateAsset(asset,path);
        return asset;
    }

    private static GameObject Block(string name, Vector3 at, Vector3 size, Material material, Transform parent,
        bool solid = true, bool local = false)
    {
        var obj = GameObject.CreatePrimitive(PrimitiveType.Cube);
        obj.name = name;
        obj.transform.SetParent(parent,false);
        if (local) obj.transform.localPosition = at;
        else obj.transform.position = at;
        obj.transform.localScale = size;
        obj.GetComponent<Renderer>().sharedMaterial = material;
        if (!solid) Object.DestroyImmediate(obj.GetComponent<Collider>());
        return obj;
    }
}

