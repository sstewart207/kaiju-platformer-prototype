Shader "Kaiju/Footfall Dust"
{
    SubShader
    {
        Tags { "Queue"="Transparent" "RenderType"="Transparent" }
        Blend SrcAlpha OneMinusSrcAlpha
        ZWrite Off
        Cull Off
        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"
            struct Input { float4 vertex : POSITION; fixed4 color : COLOR; float2 uv : TEXCOORD0; };
            struct Output { float4 pos : SV_POSITION; fixed4 color : COLOR; float2 uv : TEXCOORD0; };
            Output vert(Input v)
            {
                Output o;
                o.pos = UnityObjectToClipPos(v.vertex);
                o.uv = v.uv;
                o.color = v.color;
                return o;
            }
            fixed4 frag(Output i) : SV_Target
            {
                float2 p = i.uv * 2 - 1;
                float angle = atan2(p.y,p.x);
                float edge = .81 + .09 * cos(angle*5) + .045 * sin(angle*9);
                i.color.a *= 1 - smoothstep(edge*.37, edge, length(p));
                return i.color;
            }
            ENDCG
        }
    }
}

